# HyBrAIn — Human × AI Interaction Layer

**Your HyBrAIn Cares For You**

HyBrAIn is a Human × AI interaction layer that helps people use AI consistently through caring guidance, stress-aware support, and cognitive load regulation. It is a product interaction layer — not a medical or clinical system.

## The Problem

Most AI users fail in two opposite ways:

- **Underuse** — friction, uncertainty, no habit
- **Overuse** — cognitive overload, burnout, crash

The result: inconsistent usage. No sustainable rhythm. No trust. Session drop-off is a symptom — inconsistency is the root.

## How It Works

| Step | What Happens |
|------|-------------|
| **Signals** | User-shared stress indicators, work time, usage patterns |
| **HyBrAIn Layer** | Care · Guide · Regulate · Organize · Reflect |
| **Interventions** | Rest prompts · Task simplification · Pacing · Focus resets |
| **Outcome** | Consistent use → Retention → Stickiness → Trust |

## MVP (Build First)

One care-centered interaction layer: stress check-ins, usage rhythm tracking, overload prompts, and task simplification. Prove consistency and retention improvement first. Add predictive models and network effects later.

## Metrics

| Category | Metric |
|----------|--------|
| **North Star** | Consistent AI usage (sustainable use days / week) |
| **Human Outcome** | Lower overload episodes + better stress regulation |
| **Business Outcome** | Higher retention, stickiness, and trust |

Supporting KPIs: consistency (active days/week), overload episodes per user, week-12 retention, stickiness (habit strength).

## Tech Stack

- React + Vite
- Recharts (data visualization)
- Fraunces + DM Sans typography
- Accessibility: prefers-reduced-motion support

## Development

```bash
npm install
npm run dev
```

## Deployment

```bash
# Push to GitHub, then import on vercel.com
# Vercel auto-detects Vite → Deploy
```

---

*Confidential — 2026*
